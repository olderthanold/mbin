exit
ls
mc
sudo apt install mc
chmod /?
chmod
chmod --help
chmod --400 init-instance.sh
chmod +x init-instance.sh
ls
chmod +x init-instance.sh
./i.sh
mc
exit
./setup_oci_cli_ubuntu.sh
python
python3
python-is-python3
python3 -v
python3 --version
pip3 --version
sudo pat update
sudo apt update
sudo apt upgrade
sudo apt install -y python3-pip
mc
sudo setup_oci_cli_ubuntu.sh
sudo .
sudo -i
mc
sudo ./setup_oci_cli_ubuntu.sh
mc
sudo ./setup_oci_cli_ubuntu.sh
oci os ns get
oci setup config
ls
mc
./setup_oci_cli_ubuntu.sh
mc
./setup_oci_cli_ubuntu.sh
ls
mc
ls
cd tmmm
./setup_oci_cli_ubuntu.sh
cd ..
./setup_oci_cli_ubuntu.sh
mc
./setup_oci_cli_ubuntu.sh
exit
nano .bashrc

sudo ./setup_oci_cli_ubuntu.sh
whoami
id
sudo -v
sudo passwd ubuntu
sudo -v
./setup_oci_cli_ubuntu.sh
oci
oci setup config
OCI_BIN=$(find "$HOME" -type f -name oci -perm -111 2>/dev/null | head -n 1)
echo "$OCI_BIN"
if [ -n "$OCI_BIN" ]; then   OCI_DIR=$(dirname "$OCI_BIN");   export PATH="$OCI_DIR:$PATH";   echo "export PATH=\"$OCI_DIR:\$PATH\"" >> ~/.bashrc;   echo "export PATH=\"$OCI_DIR:\$PATH\"" >> ~/.profile;   hash -r;   oci --version; else   echo "oci binary not found under HOME";  oci; oci setup config; 
echo "$OCI_BIN"
oci --version
cd "$OCI_BIN"
cd bin
cd oci
ls
cd..
echo "$OCI_BIN"
echo "$PATH"
export PATH="$OCI_DIR:$PATH"
echo "$PATH"
export PATH2="$PATH"
echo "$PATH2"
OCI_DIR=$(dirname "$OCI_BIN")
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/home/ubuntu/bin"
oci --version
mc
exit
oci
xit
exit
oci --version
exit
./clone_user.sh
sudo ./clone_user.sh
sudo apt-get update && sudo apt-get update -y
udo apt-get update -y
sudo apt-get update -y
dir
cd mbin
cd..
cd .
cd ..
cd mbin
./ociamp
./ociamp.sh
sudo ./ociamp.sh
mc
sudo ./ociamp.sh
ls
./ociamp.sh
mc
./ociamp.sh
sudo ./ociamp.sh
oci
sudo oci
sudo .
sudo  -?
sudo bash
mcsudo apt update && sudo apt upgrade
sudo apt update && sudo apt upgrade
reboot
reboot -?
reboot --?
reboot /?
sudo reboot
nano .bashrc
oci --vesrion
sudo oci --vesrion
cd oci
dir
cd bin
ls
sudo /home/ubun2/bin/oci --version
bash sudo
sudo bash sudo
sudo bash .
cd..
cd ..
[200~sudo bash ./ociamp.sh~
sudo bash ./ociamp.sh
df
sudo -
mc
exit
echo "$PATH"
sudo bash
cd bin

sudo bash
exit
ls /root
exit
OC
help sudo
man -k sudo
info sudo
sudo -i
sudo -i ubun2
info sudo -
sudo -u
sudo -u ubun2
sudo -u ubun2 bash
sudo -i ubun2 bash
sudo -h
sudo -i
sudo -u
sudo -s
sudo -i
sudo -E -i
sudo -E bash
ls /root
env
ls
cat /home/ubun2/oldapi.pem
oci setup config
oci iam user list --compartment-id-in-subtree-search=ocid1.tenancy.oc1..xxxxxrfexxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
oci iam user list --all
oci setup repair-file-permissions --file /home/ubun2/.config/oldapi.pem
oci iam user list --all
./ociamp.sh
./ociamp.sh --debug option
./ociamp.sh
ls
ls- la
ls -la
mc
sudo mc
ps
proc
help ps
man -k ps
ps -h
ps -help
ps --help
ps --help all
ps --help simple
ps -e
ps --help simple
ps -T
ps
ps -a
mc
exit
ls
oci -version
exit
echo $!
exit
ls
nohup sudo bash ./ociamp.sh > ociamp.log 2>&1 && touch ociamp_script_completed.txt &
oci  -version
kill -9 5665
ps
ps -fp
sudo bash
sudo -i bash
sudo -E bash
oci  -version
sudo -E bash
sudo -E bash ./ociamp.sh > ociamp.log 2>&1 && touch ociamp_script_completed.txt &
oci  -version
kill -9 6116
sudo -E
exit
ls
nohup ./ociamp.sh > ociamp.log 2>&1 && touch ociamp_script_completed.txt &
kill -9 6904

./ociamp.sh
nohup ./ociamp.sh ociamp.log
exit
oci -version
exit
oci -version
exit
oci -version
exit
oci -version
sudo su - ubun2
exit
oci -version

exit
nohup sudo -E bash ./ociamp.sh > ociamp.log 2>&1 && touch ociamp_script_completed.txt &
kill -9 6116
kill -9 6566
sudo -e
sudo -E
sudo -E bash
nohup sudo -E bash ./ociamp.sh > ociamp.log 2>&1 && touch ociamp_script_completed.txt &
./ociamp.sh 
./ociamp.sh
sudo -E ./ociamp.sh
nohup sudo -E bash ./ociamp.sh > ociamp.log
ls
sudo -E ./ociamp.sh
sudo -E bash ./ociamp.sh
sudo -E bash oci --version
sudo -E bash
sudo -E bash oci -version
sudo -E bash -c oci -version
sudo -E bash -c "oci -version"
oci -version
sudo -E bash
oci -version
cat /home/ubun2/bin/oci | head -5
which oci
sudo -E bash
sudo -E bash "oci -version"
sudo -E bash -c "oci -version"
sudo -E bash oci
sudo -E bash /home/ubun2/bin/oci -version
sudo -E bash "/home/ubun2/bin/oci -version"
sudo -E bash -c "/home/ubun2/bin/oci -version"
sudo -E bash -c "oci -version"
sudo -E bash
help su
sudo su - ubun
sudo su - ubun2
exit
mc
sudo mc
exit
sudo -E bash -c "export PATH=$PATH; oci -version"
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
mc
exit
mc
export EDITOR=nano
mc
env
exit
env
mc
cd .config
cd mc
nano ini
mc
exit
which ociamp.sh
ls
cd mbin
ls
mc
exit
./i.sh
mc
sudo mc
exit
env
mc
sudo -E bash -c "export PATH=$PATH; oci -version"
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
where
which ociamp.sh
ls
mc
which ociamp.sh
ls
sudo -E bash
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
cat ociamp.sh
set
env
set
env
mc
exit
env
sudo mc
exit
env
exit
env
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
sudo -e bash
oci -version
exit
oci -version
env
exit
env
sudo mc
env
exit
sudo -E bash
mc
exit
env
exit
env
exit
env
sudo -E bash
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
sudo -E bash -c "env"
sudo -E bash -c "export PATH=$HOM; env"
sudo -E bash -c "export PATH=$PATH; "
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
sudo -E bash -c "export PATH=$PATH; env"
exit
env
mc
exit
env
env
sudo mc
sudo -E mc
when
which ociamp.sh
ls
env
exit
which oci
which ociamp.sh
mc
exit
env
sudo -E bash -c "export PATH=$PATH; "
sudo -E bash -c "oci -version"
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
sudo -E bash -c "export PATH=$PATH; which ociamp.sh"
ls
mc
sudo -E bash -c "export PATH=$PATH; cat ociamp.sh"
cat ociamp.sh
ociamp.sh
cat ociamp.sh
mc
cd mbin
ls
ociamp.sh
mc
ociamp.sh
cat ociamp.sh
sudo reboot
sudo -E bash
mc
sudo find / -name "filename.txt" 2>/dev/null
find / -name "ociamp.sh" 2>/dev/null
mc
cat ociamp.sh
ociamp.sh
oci -version
env
ociamp.sh
cat ociamp.sh
which ociamp.sh
head ociamp.sh
mbin/ociamp.sh
mc
ls
cd mbin
head ociamp.sh
cat ociamp.sh
ociamp.sh
mc
cd
ociamp.sh
exit
mc
sudo mc
~xit
exit
cat ociamp.sh
ociamp.sh
cd mbin
ls -la
ociamp.sh
mc
cd  ../bin
oci -version
cd..
cd ..
ociamp.sh
sudo -E bash -c "export PATH=$PATH; cat ociamp.sh"
sudo -E bash -c "export PATH=$PATH; ciamp.sh"
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
sudo -E bash
sudo -E bash -c "ociamp.sh"
sudo -E bash -c "mbin/ociamp.sh"
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
sudo -E bash "export PATH=$PATH; ociamp.sh"
nohup sudo -E bash -c "export PATH=$PATH; ociamp.sh" > ociamp.log 2>&1 && touch ociamp_script_completed.txt &
echo $!
touch process_1696
set
sudo -E bash -c "export PATH=$PATH; ls /root" # if path is not passed
sudo -E bash ls /root
sudo -E bash "ls /root"
sudo -E bash -c "ls /root"
proc
mc
exit
ps all
ps -f
ps -fa
exit
mc
exit
tail ociam.log
ps
mc
ls
tail ociamp.log
ps -l
ps all
tail ociamp.log
ls -la
ls-la
ls -la

ls -la
exit
mc
ls -la
sudo su -
ls -la
wget
ls -la
tail ociamp.log
help tail
man -k tail
tail /?
tail -?
tail --help
tail -n 20 ociamp.log
tail -f -n 20 ociamp.log
ls -la
exit
mc
tail -f -n 20 ociamp.log
exit
tail -f -n 20 ociamp.log
ls -la
tail -f -n 20 ociamp.log
ls -la
exit
ps all
ls -la
exit
ls -la
exit
ls -la
ps all
tail -f -n 20 ociamp.log
tail 20 ociamp.log
tail -f 20 ociamp.log
tail -n 20 ociamp.log
man tail
tail --help
tail 20 ociamp.log
exit
ls
ls -la
tail 20 ociamp.log
mc
ls -la
exit
grep -RniE '^(PasswordAuthentication|KbdInteractiveAuthentication|UsePAM)\b' /etc/ssh/sshd_config /etc/ssh/sshd_config.d
sshd -T -C user=root,host=localhost,addr=127.0.0.1 | grep -iE 'passwordauthentication|kbdinteractiveauthentication|usepam'
sshd
exit
ls -la
sshd -T -C user=root,host=localhost,addr=127.0.0.1 | grep -iE 'passwordauthentication|kbdinteractiveauthentication|usepam'
grep -RniE '^(PasswordAuthentication|KbdInteractiveAuthentication|UsePAM)\b' /etc/ssh/sshd_config /etc/ssh/sshd_config.d
tail -f 20 ociamp.log
ls -la
exit
ls -la
exit
ls -la
ps -l
ps -la
ls -la
tail ociamp.log 
head ociamp.log 
head -l 20ociamp.log 
head -l 20 ociamp.log 
head --help
head -n 20 ociamp.log 
exit
ls
head -n 20 ociamp.log 
ls -la
exit
env
sudo /opt/mbin/0init.sh 
sudo systemctl restart ssh
exit
ls
ls -la
env
git_mbin.sh
mbin/git_mbin.sh
ls
cd mbin
ls
cd ..
git clone https://github.com/olderthanold/mbin.git 
git ls-remote https://github.com/olderthanold/mbin.git
sudo git clone -b main https://github.com/olderthanold/mbin.git /opt/mbin
sudo /opt/mbin/git_mbin.sh 
mc
exit
mc
sudo 0web.sh olderthanold.duckdns.org
ls
ls -la
head ociamp.log 
head --help
head -n 30 ociamp.log 
tail -n 30 ociamp.log 
tail -n 30
exit
git_web.sh 
sudo git_web.sh 
sudo mc
0web.sh 89.168.88.88mc
sudo mc
0web.sh 
sudo 0web.sh oldneues.duckdns.org oldneues
sudo systemctl restart ngnix
sudo systemctl restart nginx
ls -la
mc
ls -la
exit
sudo mc
exit
ls -la
tail -l 20 ociamp.log
tldr tail
sudo apt install tealdeer
bat
sudo apt install bacula-console-qt
exit
mc
exit
ls -la
exit
xit
exit
sftpc
exit
update_inst.sh 
sudo reboot
exit
ls -la
git_update.sh
cd mbin
ls
cd ..
sudo git clone -b main https://github.com/olderthanold/mbin.git mm
cd mm
ls
chmod +X ./*
sudo chmod +X ./*.sh
ls
ll
./git_mbin_ssh.sh
sudo  
ls
sudo rm -r mm
ls
ll
git clone -b main https://github.com/olderthanold/mbin.git mm
cd  mm
ll
sudo ./git_mbin_ssh.sh
sudo ./git_mbin_http.sh 
init_0_main.sh 
sudo init_0_main.sh 
top
ll
cd ..
ll
cd mbin
ll
cd ..
mc
~~
ll
ps
ll
mc
sudo git_mbin_ssh.sh 
mc
sudo git_mbin_ssh.sh 
ll
git_mbin_
git_mbin_ssh.dh
git_mbin_ssh.sh
sudo git_mbin_ssh.sh
cd mm
ls
sudo ./init_0_main.sh 
env
mc
env
mc
sudo reboot
ls
env
sudo mc
sudo mm/git_mbin_ssh.sh 
mc
sudo mm/git_mbin_ssh.sh 
ssh-keygen -?
ssh-keygen -Y /home/ubun2/.ssh/old.key
ssh-keygen -V /home/ubun2/.ssh/old.key
mc
nano
exit
3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
mc
sudo mm/git_mbin_ssh.sh 
ssh-keygen -V /home/ubun2/.ssh/old.key
mc
~
mc
~www
ssh-keygen -V /home/ubun2/.ssh/old.key
sudo mm/git_mbin_ssh.sh 
inmc
mc
ll mbin
mbin/run_ociamp.sh 
ll
mc
exit
swapon --show
free -h
exit
ps -A
ll
ps
ps -a
mc
ps -A
ps -la
mc
exit
mc
exit
fdsk
fdisk
fdisk -l
sudo fdisk -l
lsblk
sudo parted -l
sudo fdisk -?
sudo fdisk -h
sudo fdisk -l
sudo fdisk -L
sudo fdisk -L -l
sudo fdisk -h
sudo fdisk /dev/sda1
sudo fdisk -h
sudo fdisk -l /dev/sda1
sudo diskpart -h
sudo fdisk -l /dev/sda1
sudo parted =h
sudo parted -h
sudo parted -l
sudo parted 1
ps -l
ps -la
fg
ps -la
fg oci
fg
git_mbin_ssh.sh 
sudo git_mbin_ssh.sh 
0ini.sh 
sudo 0ini.sh 
sudo git_mbin_http.sh 
statsm
statsm.sh
mc
exit
ls
mc
0;45;42M0;45;42m
exit
ls
sudo git_mbin_ssh.sh 
sudo mgit_ssh.sh 
mstats.sh 
lynx http://10.0.159.254:8080
sudo mgit_ssh.sh
sudo 0ini.sh 
nohup bash -c 'sudo -E bash -c "export PATH=$PATH; /opt/mbin/ai/aibuild.sh" && touch ociamp_script_completed.txt' > ociamp.log 2>error.log &
echo $!
ps
mc
ps -l
ps -la
kill -9 17946
ps -la
mc
la -la
ps -la
kill -9 17947
kill -9 17949
ps -la
ls -la
ps -la
kill -9 19126
ps -la
kill -9 19149
ps -la
kill -9 19149
ls -la
nohup bash -c 'sudo -E bash -c "export PATH=$PATH; ociamp.sh" && touch ociamp_script_completed.txt' > ociamp02.log 2>&1 &
echo $!
ps -la
ls -la
sudo reboot
sudo mgit_ssh.sh 
mstats.sh 
nano .bashrc
~
exit
mc
mstats.sh 
mc
exit
ps -la
tmux new -s ociclim
tmux ls
tmux new -s aibuild
tmux ls
exit
tmux ls
tmux attach -t aibuild
ls
cd ai
ls
rm -r llama.cpp/
rm -r llama.cpp
sudo rm -r llama.cpp
ls
/opt/mbin/ai/aibuild.sh
ls
cd ..
/opt/mbin/ai/aibuild.sh
ls
cd ai
ls
rm --help
cd ..
rm -rf ai
ls
ls -la
sudo /opt/mbin/ai/aibuild.sh
ls
mc
mstats.sh 
sudo bash
ls -la
ps -la
tmux ls
mstats.sh 
tmux -h
tmux attach -t aibuild
exit
61;4;6;7;14;21;22;23;24;28;32;42;52c0;10;1c
ls
sudo ociamp.sh 
sudo /opt/mbin/oci_cli/ociamp.sh 
mc
cd mbin
ls
./ociamp.sh 
sudo ./ociamp.sh 
sudo /home/ubun2/mbin/ociamp.sh 
sudo -E bash -c "export PATH=$PATH; ociamp.sh"
exit
sudo mgit_ssh.sh 
rm -rd ai
ls
aibenv
env
ls
cd  mbin
ls
cd ..
sudo /opt/mbin/ai/aibuild.sh 
tmux ls
tmux attach -t ociclim
tmux ls
tmux -?
tmux new marek
tmux ls
tmux new -s marek
exit
tmux ls
tmux new -s marek
tmux ls
tmux attach -t marek
tmux ls
ps -la
exit
tmux ls
tmux attach -t aimbuild
tmux attach -t aibuild
tmux ls
tmux attach -t aibuild
sudo env
cd /
cd home
cd ubun2
pwd
mc
sudo mgit_ssh.sh 
mgit_ssh.sh 
ps -la
exit
mc
mbin/run_ociamp.sh 
touch ocic_7571
mc
sudo /opt/mbin/ai/buildrun_ai.sh 
mc
sudo /opt/mbin/ai/buildrun_ai.sh 
mc
sudo mc
ps -la
ecit
xit
exit
sudo mgit_ssh.sh 
ls
sudo bash
ls -la
mc
sudo mc
mg
sudo mgit_ssh.sh 
mc
sudo mc
/opt/mbin/ai/aibuild.sh
ls
mc
sudo mgit_ssh.sh 
/opt/mbin/ai/buildrun_ai.sh 
ps -la
exit
ps -lka
ps -la
top
mc
ps -la
ls -la
ls -Fa
ps -Fa
kill -9 7573
ps -Fa
/opt/mbin/ai/buildrun_ai.sh 
mc
sudo mc
exit
ls -la
mc
cd ai/llama.cpp/build/bin/
exit
[<0;47;1M
mc
/home/ubun2/ai/llama.cpp/build/bin/llama-cli -hf unsloth/gemma-3-1b-it-GGUF:Q3_K_S --no-mmproj
/home/ubun2/ai/llama.cpp/build/bin/llama-cli -hf daniloreddy/gemma-4-E2B-it_GGUF:Q4_K_M -p "User: Hello! Assistant:" -n 512 --temp 0.7 --no-mmproj
/home/ubun2/ai/llama.cpp/build/bin/llama-cli -hf daniloreddy/gemma-4-E2B-it_GGUF:Q4_K_M --no-mmproj -p "User: Hello! Assistant:" -n 512 --temp 0.7
/home/ubun2/ai/llama.cpp/build/bin/llama-cli -hf daniloreddy/gemma-4-E2B-it_GGUF:Q4_K_M --mmproj-auto 0 -p "User: Hello! Assistant:" -n 512 --temp 0.7
/home/ubun2/ai/llama.cpp/build/bin/llama-cli -hf daniloreddy/gemma-4-E2B-it_GGUF:Q4_K_M --mmproj-auto -p "User: Hello! Assistant:" -n 512 --temp 0.7
/home/ubun2/ai/llama.cpp/build/bin/llama-cli -hf daniloreddy/gemma-4-E2B-it_GGUF:Q4_K_M --no-mmproj -p "User: Hello! Assistant[B:" -n 512 --temp 0.7
/home/ubun2/ai/llama.cpp/build/bin/llama-cli -hf daniloreddy/gemma-4-E2B-it_GGUF:Q4_K_S --reasoning off -n 512 --temp 0.7 --no-mmproj
/home/ubun2/ai/llama.cpp/build/bin/llama-cli -hf bartowski/Qwen_Qwen3.5-0.8B-GGUF:Q3_K_S  --reasoning off -n 512 --temp 0.7 --no-mmproj
/home/ubun2/ai/llama.cpp/build/bin/llama-cli -hf bartowski/Qwen_Qwen3.5-2B-GGUF:Q3_K_S  --reasoning off -n 512 --temp 0.7 --no-mmproj
mgit_ssh.sh 
sudo mgit_ssh.sh 
exit
